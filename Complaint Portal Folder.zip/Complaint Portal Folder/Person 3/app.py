from flask import Flask, render_template, request, redirect, url_for,jsonify
from flask_cors import CORS
app = Flask(__name__)
CORS(app)
complaints = [
    {"id": 1, "name": "Ravi Kumar", "facility": "Water Supply", "location": "Ward 5", "status": "Pending"},
    {"id": 2, "name": "Priya S", "facility": "Street Light", "location": "Ward 2", "status": "Resolved"},
    {"id": 3, "name": "Arun M", "facility": "Road Damage", "location": "Ward 8", "status": "In Progress"},
]

@app.route('/')
def home():
    return "Public Facility Complaint Portal - Home"

@app.route('/admin')
def admin():
    filter_status = request.args.get('filter', 'All')
    search = request.args.get('search', '').lower()

    filtered = complaints
    if filter_status != 'All':
        filtered = [c for c in filtered if c['status'] == filter_status]
    if search:
        filtered = [c for c in filtered if search in c['name'].lower() or search in c['location'].lower()]

    return render_template('admin.html', complaints=filtered, all_complaints=complaints, filter_status=filter_status, search=search)

@app.route('/update_status/<int:id>', methods=['POST'])
def update_status(id):
    new_status = request.form.get('status')
    for c in complaints:
        if c['id'] == id:
            c['status'] = new_status
            break
    return redirect(url_for('admin'))
@app.route('/add_complaint', methods=['POST'])
def add_complaint():
    if request.is_json:
        data = request.get_json()
        name = data.get('name')
        facility = data.get('facility')
        location = data.get('location')
    else:
        name = request.form.get('name')
        facility = request.form.get('facility')
        location = request.form.get('location')

    new_id = max([c['id'] for c in complaints], default=0) + 1

    complaints.append({
        "id": new_id,
        "name": name,
        "facility": facility,
        "location": location,
        "status": "Pending"
    })

    if request.is_json:
        return jsonify({"success": True, "id": new_id})

    return redirect(url_for('admin'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')